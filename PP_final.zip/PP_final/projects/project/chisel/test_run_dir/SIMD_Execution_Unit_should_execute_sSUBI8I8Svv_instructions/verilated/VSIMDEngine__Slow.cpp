// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VSIMDEngine.h for the primary calling header

#include "VSIMDEngine.h"
#include "VSIMDEngine__Syms.h"

//==========

VSIMDEngine::VSIMDEngine(VerilatedContext* _vcontextp__, const char* _vcname__)
    : VerilatedModule{_vcname__}
 {
    VSIMDEngine__Syms* __restrict vlSymsp = __VlSymsp = new VSIMDEngine__Syms(_vcontextp__, this, name());
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Reset internal values
    
    // Reset structure values
    _ctor_var_reset();
}

void VSIMDEngine::__Vconfigure(VSIMDEngine__Syms* vlSymsp, bool first) {
    if (false && first) {}  // Prevent unused
    this->__VlSymsp = vlSymsp;
    if (false && this->__VlSymsp) {}  // Prevent unused
    _configure_coverage(vlSymsp, first);
    vlSymsp->_vm_contextp__->timeunit(-12);
    vlSymsp->_vm_contextp__->timeprecision(-12);
}

VSIMDEngine::~VSIMDEngine() {
    VL_DO_CLEAR(delete __VlSymsp, __VlSymsp = nullptr);
}

// Coverage
void VSIMDEngine::__vlCoverInsert(uint32_t* countp, bool enable, const char* filenamep, int lineno, int column,
    const char* hierp, const char* pagep, const char* commentp, const char* linescovp) {
    uint32_t* count32p = countp;
    static uint32_t fake_zero_count = 0;
    if (!enable) count32p = &fake_zero_count;
    *count32p = 0;
    VL_COVER_INSERT(__VlSymsp->_vm_contextp__->coveragep(), count32p,  "filename",filenamep,  "lineno",lineno,  "column",column,
        "hier",std::string(name())+hierp,  "page",pagep,  "comment",commentp,  (linescovp[0] ? "linescov" : ""), linescovp);
}

void VSIMDEngine::_initial__TOP__1(VSIMDEngine__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VSIMDEngine::_initial__TOP__1\n"); );
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->io_cmd_payload_ready = 1U;
}

void VSIMDEngine::_settle__TOP__3(VSIMDEngine__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VSIMDEngine::_settle__TOP__3\n"); );
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->io_rsp_payload_valid = ((IData)(vlTOPp->io_cmd_payload_valid) 
                                    & (IData)(vlTOPp->io_rsp_payload_ready));
    vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7 
        = (0xffffU & (vlTOPp->io_cmd_payload_bits_rs1 
                      + vlTOPp->io_cmd_payload_bits_rs2));
    vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14 
        = (0xffffU & (vlTOPp->io_cmd_payload_bits_rs1 
                      - vlTOPp->io_cmd_payload_bits_rs2));
    vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_7 
        = (0xffU & (vlTOPp->io_cmd_payload_bits_rs1 
                    + vlTOPp->io_cmd_payload_bits_rs2));
    vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_14 
        = (0xffU & (vlTOPp->io_cmd_payload_bits_rs1 
                    - vlTOPp->io_cmd_payload_bits_rs2));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_23 
        = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                            & VL_EXTENDS_II(16,8, 
                                                            (0xffU 
                                                             & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                >> 8U)))), 
                                 (0xffffU & VL_EXTENDS_II(16,8, 
                                                          (0xffU 
                                                           & (vlTOPp->io_cmd_payload_bits_rs2 
                                                              >> 8U))))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_23 
        = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                            & VL_EXTENDS_II(16,8, 
                                                            (0xffU 
                                                             & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                >> 0x10U)))), 
                                 (0xffffU & VL_EXTENDS_II(16,8, 
                                                          (0xffU 
                                                           & (vlTOPp->io_cmd_payload_bits_rs2 
                                                              >> 0x10U))))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_23 
        = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                            & VL_EXTENDS_II(16,8, 
                                                            (0xffU 
                                                             & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                >> 0x18U)))), 
                                 (0xffffU & VL_EXTENDS_II(16,8, 
                                                          (0xffU 
                                                           & (vlTOPp->io_cmd_payload_bits_rs2 
                                                              >> 0x18U))))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_45 
        = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                            & VL_EXTENDS_II(16,8, 
                                                            (0xffU 
                                                             & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                >> 8U)))), 
                                 (0xffffU & VL_EXTENDS_II(16,8, 
                                                          (0xffU 
                                                           & vlTOPp->io_cmd_payload_bits_rs2)))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_45 
        = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                            & VL_EXTENDS_II(16,8, 
                                                            (0xffU 
                                                             & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                >> 0x10U)))), 
                                 (0xffffU & VL_EXTENDS_II(16,8, 
                                                          (0xffU 
                                                           & vlTOPp->io_cmd_payload_bits_rs2)))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_45 
        = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                            & VL_EXTENDS_II(16,8, 
                                                            (0xffU 
                                                             & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                >> 0x18U)))), 
                                 (0xffffU & VL_EXTENDS_II(16,8, 
                                                          (0xffU 
                                                           & vlTOPp->io_cmd_payload_bits_rs2)))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_23 
        = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                            & VL_EXTENDS_II(16,8, 
                                                            (0xffU 
                                                             & vlTOPp->io_cmd_payload_bits_rs1))), 
                                 (0xffffU & VL_EXTENDS_II(16,8, 
                                                          (0xffU 
                                                           & vlTOPp->io_cmd_payload_bits_rs2)))));
    vlTOPp->SIMDEngine__DOT__controller__DOT__funct 
        = (((IData)(vlTOPp->io_cmd_payload_bits_funct7) 
            << 3U) | (IData)(vlTOPp->io_cmd_payload_bits_funct3));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_7 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & (vlTOPp->io_cmd_payload_bits_rs1 
                                                          >> 0xfU)))) 
                                           << 0x10U)) 
                           | (0xffffU & vlTOPp->io_cmd_payload_bits_rs1)) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_7 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & (vlTOPp->io_cmd_payload_bits_rs1 
                                                          >> 0x1fU)))) 
                                           << 0x10U)) 
                           | (0xffffU & (vlTOPp->io_cmd_payload_bits_rs1 
                                         >> 0x10U))) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_7 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & (vlTOPp->io_cmd_payload_bits_rs2 
                                                          >> 0xfU)))) 
                                           << 0x10U)) 
                           | (0xffffU & vlTOPp->io_cmd_payload_bits_rs2)) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_7 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & (vlTOPp->io_cmd_payload_bits_rs2 
                                                          >> 0x1fU)))) 
                                           << 0x10U)) 
                           | (0xffffU & (vlTOPp->io_cmd_payload_bits_rs2 
                                         >> 0x10U))) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_15 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (0xffffU 
                                              & vlTOPp->io_cmd_payload_bits_rs1), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_15 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (0xffffU 
                                              & (vlTOPp->io_cmd_payload_bits_rs1 
                                                 >> 0x10U)), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_15 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (0xffffU 
                                              & vlTOPp->io_cmd_payload_bits_rs2), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_15 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (0xffffU 
                                              & (vlTOPp->io_cmd_payload_bits_rs2 
                                                 >> 0x10U)), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__register_io_rsMatch = 
        ((vlTOPp->io_cmd_payload_bits_rs1 == vlTOPp->SIMDEngine__DOT__register__DOT__rsReg_0) 
         & (vlTOPp->io_cmd_payload_bits_rs2 == vlTOPp->SIMDEngine__DOT__register__DOT__rsReg_1));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_27 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_23) 
                                                          >> 0xfU)))) 
                                           << 0x10U)) 
                           | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_23)) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_37 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_23), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_27 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_23) 
                                                          >> 0xfU)))) 
                                           << 0x10U)) 
                           | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_23)) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_37 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_23), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_27 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_23) 
                                                          >> 0xfU)))) 
                                           << 0x10U)) 
                           | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_23)) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_37 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_23), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_49 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_45) 
                                                          >> 0xfU)))) 
                                           << 0x10U)) 
                           | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_45)) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_59 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_45), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_49 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_45) 
                                                          >> 0xfU)))) 
                                           << 0x10U)) 
                           | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_45)) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_59 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_45), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_49 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_45) 
                                                          >> 0xfU)))) 
                                           << 0x10U)) 
                           | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_45)) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_59 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_45), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_27 
        = (0x7fffffffU & (((0x7fff0000U & ((- (IData)(
                                                      (1U 
                                                       & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_23) 
                                                          >> 0xfU)))) 
                                           << 0x10U)) 
                           | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_23)) 
                          << (0xfU & (- vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor))));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_37 
        = (0xffffU & VL_SHIFTRS_III(16,16,4, (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_23), 
                                    (0xfU & vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)));
    vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel 
        = (((IData)(vlTOPp->io_cmd_payload_valid) & (IData)(vlTOPp->io_rsp_payload_ready))
            ? ((0x209U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                ? 8U : ((0x208U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                         ? 7U : ((0x201U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                  ? 6U : ((0x200U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                           ? 5U : (
                                                   (9U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                                    ? 4U
                                                    : 
                                                   ((8U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                                     ? 3U
                                                     : 
                                                    ((1U 
                                                      == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                                      ? 2U
                                                      : 
                                                     (0U 
                                                      == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct)))))))))
            : 0U);
    vlTOPp->SIMDEngine__DOT__controller__DOT___io_wenRs_T_3 
        = ((0x214U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct)) 
           | (0x14U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct)));
    if (((IData)(vlTOPp->io_cmd_payload_valid) & (IData)(vlTOPp->io_rsp_payload_ready))) {
        vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel 
            = ((0x211U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                ? 2U : ((0x11U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                         ? 1U : ((0x3aU == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                  ? 5U : ((0x39U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                           ? 4U : (
                                                   (0x38U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                                    ? 3U
                                                    : 0U)))));
        vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel 
            = ((0x215U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                ? ((IData)(vlTOPp->SIMDEngine__DOT__register_io_rsMatch)
                    ? 0U : 6U) : ((0x214U == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                   ? 5U : ((0x210U 
                                            == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                            ? 4U : 
                                           ((0x15U 
                                             == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                             ? ((IData)(vlTOPp->SIMDEngine__DOT__register_io_rsMatch)
                                                 ? 0U
                                                 : 3U)
                                             : ((0x14U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct))
                                                 ? 2U
                                                 : 
                                                (0x10U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT__funct)))))));
    } else {
        vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel = 0U;
        vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel = 0U;
    }
    vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT__rdByteConcat 
        = ((0xff000000U & (((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                             ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                 >> 0x18U) - vlTOPp->io_cmd_payload_bits_rs2)
                             : ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                 ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                     >> 0x18U) + vlTOPp->io_cmd_payload_bits_rs2)
                                 : ((3U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                     ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                         >> 0x18U) 
                                        - (vlTOPp->io_cmd_payload_bits_rs2 
                                           >> 0x18U))
                                     : ((1U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                         ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                             >> 0x18U) 
                                            + (vlTOPp->io_cmd_payload_bits_rs2 
                                               >> 0x18U))
                                         : 0U)))) << 0x18U)) 
           | ((0xff0000U & (((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                              ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                  >> 0x10U) - vlTOPp->io_cmd_payload_bits_rs2)
                              : ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                  ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                      >> 0x10U) + vlTOPp->io_cmd_payload_bits_rs2)
                                  : ((3U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                      ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                          >> 0x10U) 
                                         - (vlTOPp->io_cmd_payload_bits_rs2 
                                            >> 0x10U))
                                      : ((1U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                          ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                              >> 0x10U) 
                                             + (vlTOPp->io_cmd_payload_bits_rs2 
                                                >> 0x10U))
                                          : 0U)))) 
                            << 0x10U)) | ((0xff00U 
                                           & (((7U 
                                                == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                ? (
                                                   (vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 8U) 
                                                   - vlTOPp->io_cmd_payload_bits_rs2)
                                                : (
                                                   (5U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? 
                                                   ((vlTOPp->io_cmd_payload_bits_rs1 
                                                     >> 8U) 
                                                    + vlTOPp->io_cmd_payload_bits_rs2)
                                                    : 
                                                   ((3U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                     ? 
                                                    ((vlTOPp->io_cmd_payload_bits_rs1 
                                                      >> 8U) 
                                                     - 
                                                     (vlTOPp->io_cmd_payload_bits_rs2 
                                                      >> 8U))
                                                     : 
                                                    ((1U 
                                                      == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                      ? 
                                                     ((vlTOPp->io_cmd_payload_bits_rs1 
                                                       >> 8U) 
                                                      + 
                                                      (vlTOPp->io_cmd_payload_bits_rs2 
                                                       >> 8U))
                                                      : 0U)))) 
                                              << 8U)) 
                                          | ((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                              ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_14)
                                              : ((5U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_7)
                                                  : 
                                                 ((3U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_14)
                                                   : 
                                                  ((1U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_7)
                                                    : 0U)))))));
    vlTOPp->SIMDEngine__DOT__controller_io_wenRs = 
        (((IData)(vlTOPp->io_cmd_payload_valid) & (IData)(vlTOPp->io_rsp_payload_ready)) 
         & (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT___io_wenRs_T_3));
    vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat 
        = ((0xff000000U & (((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                             ? ((0xff00U & ((- (IData)(
                                                       (1U 
                                                        & (vlTOPp->io_cmd_payload_bits_rs2 
                                                           >> 0x1fU)))) 
                                            << 8U)) 
                                | (0xffU & (vlTOPp->io_cmd_payload_bits_rs2 
                                            >> 0x18U)))
                             : ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                 ? (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                     ? (((0x80000000U 
                                          & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_7 
                                             << 1U)) 
                                         | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_7) 
                                        + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                     : (((0xffff0000U 
                                          & ((- (IData)(
                                                        (1U 
                                                         & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_15) 
                                                            >> 0xfU)))) 
                                             << 0x10U)) 
                                         | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_15)) 
                                        + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                 : ((1U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                     ? (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                         ? (((0x80000000U 
                                              & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_27 
                                                 << 1U)) 
                                             | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_27) 
                                            + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                         : (((0xffff0000U 
                                              & ((- (IData)(
                                                            (1U 
                                                             & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_37) 
                                                                >> 0xfU)))) 
                                                 << 0x10U)) 
                                             | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_37)) 
                                            + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                     : (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                         ? (((0x80000000U 
                                              & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_49 
                                                 << 1U)) 
                                             | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_49) 
                                            + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                         : (((0xffff0000U 
                                              & ((- (IData)(
                                                            (1U 
                                                             & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_59) 
                                                                >> 0xfU)))) 
                                                 << 0x10U)) 
                                             | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_59)) 
                                            + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))) 
                           << 0x18U)) | ((0xff0000U 
                                          & (((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                               ? ((0xff00U 
                                                   & ((- (IData)(
                                                                 (1U 
                                                                  & (vlTOPp->io_cmd_payload_bits_rs2 
                                                                     >> 0xfU)))) 
                                                      << 8U)) 
                                                  | (0xffU 
                                                     & (vlTOPp->io_cmd_payload_bits_rs2 
                                                        >> 8U)))
                                               : ((5U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                   ? 
                                                  (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                    ? 
                                                   (((0x80000000U 
                                                      & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_7 
                                                         << 1U)) 
                                                     | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_7) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                    : 
                                                   (((0xffff0000U 
                                                      & ((- (IData)(
                                                                    (1U 
                                                                     & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_15) 
                                                                        >> 0xfU)))) 
                                                         << 0x10U)) 
                                                     | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_15)) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                   : 
                                                  ((1U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                    ? 
                                                   (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                     ? 
                                                    (((0x80000000U 
                                                       & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_27 
                                                          << 1U)) 
                                                      | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_27) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                     : 
                                                    (((0xffff0000U 
                                                       & ((- (IData)(
                                                                     (1U 
                                                                      & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_37) 
                                                                         >> 0xfU)))) 
                                                          << 0x10U)) 
                                                      | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_37)) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                    : 
                                                   (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                     ? 
                                                    (((0x80000000U 
                                                       & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_49 
                                                          << 1U)) 
                                                      | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_49) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                     : 
                                                    (((0xffff0000U 
                                                       & ((- (IData)(
                                                                     (1U 
                                                                      & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_59) 
                                                                         >> 0xfU)))) 
                                                          << 0x10U)) 
                                                      | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_59)) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))) 
                                             << 0x10U)) 
                                         | ((0xff00U 
                                             & (((4U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                  ? 
                                                 ((0xff00U 
                                                   & ((- (IData)(
                                                                 (1U 
                                                                  & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                     >> 0x1fU)))) 
                                                      << 8U)) 
                                                  | (0xffU 
                                                     & (vlTOPp->io_cmd_payload_bits_rs1 
                                                        >> 0x18U)))
                                                  : 
                                                 ((5U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                   ? 
                                                  (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                    ? 
                                                   (((0x80000000U 
                                                      & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_7 
                                                         << 1U)) 
                                                     | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_7) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                    : 
                                                   (((0xffff0000U 
                                                      & ((- (IData)(
                                                                    (1U 
                                                                     & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_15) 
                                                                        >> 0xfU)))) 
                                                         << 0x10U)) 
                                                     | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_15)) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                   : 
                                                  ((1U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                    ? 
                                                   (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                     ? 
                                                    (((0x80000000U 
                                                       & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_27 
                                                          << 1U)) 
                                                      | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_27) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                     : 
                                                    (((0xffff0000U 
                                                       & ((- (IData)(
                                                                     (1U 
                                                                      & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_37) 
                                                                         >> 0xfU)))) 
                                                          << 0x10U)) 
                                                      | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_37)) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                    : 
                                                   (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                     ? 
                                                    (((0x80000000U 
                                                       & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_49 
                                                          << 1U)) 
                                                      | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_49) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                     : 
                                                    (((0xffff0000U 
                                                       & ((- (IData)(
                                                                     (1U 
                                                                      & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_59) 
                                                                         >> 0xfU)))) 
                                                          << 0x10U)) 
                                                      | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_59)) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))) 
                                                << 8U)) 
                                            | (0xffU 
                                               & ((4U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                   ? 
                                                  ((0xff00U 
                                                    & ((- (IData)(
                                                                  (1U 
                                                                   & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                      >> 0xfU)))) 
                                                       << 8U)) 
                                                   | (0xffU 
                                                      & (vlTOPp->io_cmd_payload_bits_rs1 
                                                         >> 8U)))
                                                   : 
                                                  ((5U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                    ? 
                                                   (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                     ? 
                                                    (((0x80000000U 
                                                       & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_7 
                                                          << 1U)) 
                                                      | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_7) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                     : 
                                                    (((0xffff0000U 
                                                       & ((- (IData)(
                                                                     (1U 
                                                                      & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_15) 
                                                                         >> 0xfU)))) 
                                                          << 0x10U)) 
                                                      | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_15)) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                    : 
                                                   (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                     ? 
                                                    (((0x80000000U 
                                                       & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_27 
                                                          << 1U)) 
                                                      | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_27) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                     : 
                                                    (((0xffff0000U 
                                                       & ((- (IData)(
                                                                     (1U 
                                                                      & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_37) 
                                                                         >> 0xfU)))) 
                                                          << 0x10U)) 
                                                      | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_37)) 
                                                     + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))))));
    vlTOPp->SIMDEngine__DOT__controller_io_outputSel 
        = ((0U != (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
            ? 0U : ((0U != (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                     ? 1U : ((0U != (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                              ? 2U : 3U)));
    vlTOPp->SIMDEngine__DOT__mulUnit__DOT___T_3 = (
                                                   ((3U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel)) 
                                                    << 2U) 
                                                   | (((2U 
                                                        == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel)) 
                                                       << 1U) 
                                                      | (1U 
                                                         == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))));
    if ((0U != (IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT___T_3))) {
        vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_1 
            = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                                & VL_EXTENDS_II(16,8, 
                                                                (0xffU 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                    >> 8U)))), 
                                     (0xffffU & VL_EXTENDS_II(16,8, 
                                                              (0xffU 
                                                               & (vlTOPp->io_cmd_payload_bits_rs2 
                                                                  >> 8U))))));
        vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_2 
            = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                                & VL_EXTENDS_II(16,8, 
                                                                (0xffU 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                    >> 0x10U)))), 
                                     (0xffffU & VL_EXTENDS_II(16,8, 
                                                              (0xffU 
                                                               & (vlTOPp->io_cmd_payload_bits_rs2 
                                                                  >> 0x10U))))));
        vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_3 
            = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                                & VL_EXTENDS_II(16,8, 
                                                                (0xffU 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                    >> 0x18U)))), 
                                     (0xffffU & VL_EXTENDS_II(16,8, 
                                                              (0xffU 
                                                               & (vlTOPp->io_cmd_payload_bits_rs2 
                                                                  >> 0x18U))))));
    } else {
        vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_1 
            = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                                & VL_EXTENDS_II(16,8, 
                                                                (0xffU 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                    >> 8U)))), 
                                     (0xffffU & VL_EXTENDS_II(16,8, 
                                                              (0xffU 
                                                               & vlTOPp->io_cmd_payload_bits_rs2)))));
        vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_2 
            = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                                & VL_EXTENDS_II(16,8, 
                                                                (0xffU 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                    >> 0x10U)))), 
                                     (0xffffU & VL_EXTENDS_II(16,8, 
                                                              (0xffU 
                                                               & vlTOPp->io_cmd_payload_bits_rs2)))));
        vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_3 
            = (0xffffU & VL_MULS_III(16,16,16, (0xffffU 
                                                & VL_EXTENDS_II(16,8, 
                                                                (0xffU 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                    >> 0x18U)))), 
                                     (0xffffU & VL_EXTENDS_II(16,8, 
                                                              (0xffU 
                                                               & vlTOPp->io_cmd_payload_bits_rs2)))));
    }
    vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat 
        = (((IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_1) 
            << 0x10U) | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_23));
    vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat 
        = (((IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_3) 
            << 0x10U) | (IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_2));
    vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat 
        = ((0xff000000U & ((IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_3) 
                           << 0x10U)) | ((0xff0000U 
                                          & ((IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_2) 
                                             << 8U)) 
                                         | ((0xff00U 
                                             & (IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_1)) 
                                            | (0xffU 
                                               & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_23) 
                                                  >> 8U)))));
    vlTOPp->io_rsp_payload_bits_rd = ((3U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_outputSel))
                                       ? vlTOPp->SIMDEngine__DOT__register__DOT__rdMsbReg
                                       : ((2U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_outputSel))
                                           ? ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                               ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                               : ((4U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                   ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                                   : 
                                                  ((2U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                    ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                                    : 
                                                   ((1U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                     ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                                     : 0U))))
                                           : ((1U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_outputSel))
                                               ? ((6U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                   ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat
                                                   : 
                                                  ((5U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                    ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat
                                                    : 
                                                   ((3U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                     ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat
                                                     : 
                                                    ((2U 
                                                      == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                      ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat
                                                      : 
                                                     ((4U 
                                                       == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                       ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat
                                                       : 
                                                      ((1U 
                                                        == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                        ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat
                                                        : 0U))))))
                                               : ((0U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_outputSel))
                                                   ? 
                                                  (((7U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)) 
                                                    | ((5U 
                                                        == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)) 
                                                       | ((3U 
                                                           == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)) 
                                                          | (1U 
                                                             == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)))))
                                                    ? vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT__rdByteConcat
                                                    : 
                                                   ((0xffff0000U 
                                                     & (((8U 
                                                          == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                          ? 
                                                         ((vlTOPp->io_cmd_payload_bits_rs1 
                                                           >> 0x10U) 
                                                          - vlTOPp->io_cmd_payload_bits_rs2)
                                                          : 
                                                         ((6U 
                                                           == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                           ? 
                                                          ((vlTOPp->io_cmd_payload_bits_rs1 
                                                            >> 0x10U) 
                                                           + vlTOPp->io_cmd_payload_bits_rs2)
                                                           : 
                                                          ((4U 
                                                            == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                            ? 
                                                           ((vlTOPp->io_cmd_payload_bits_rs1 
                                                             >> 0x10U) 
                                                            - 
                                                            (vlTOPp->io_cmd_payload_bits_rs2 
                                                             >> 0x10U))
                                                            : 
                                                           ((2U 
                                                             == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                             ? 
                                                            ((vlTOPp->io_cmd_payload_bits_rs1 
                                                              >> 0x10U) 
                                                             + 
                                                             (vlTOPp->io_cmd_payload_bits_rs2 
                                                              >> 0x10U))
                                                             : 0U)))) 
                                                        << 0x10U)) 
                                                    | ((8U 
                                                        == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                        ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                                        : 
                                                       ((6U 
                                                         == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                         ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                                         : 
                                                        ((4U 
                                                          == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                          ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                                          : 
                                                         ((2U 
                                                           == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                           ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                                           : 0U))))))
                                                   : 0U))));
}

void VSIMDEngine::_eval_initial(VSIMDEngine__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VSIMDEngine::_eval_initial\n"); );
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_initial__TOP__1(vlSymsp);
    vlTOPp->__Vclklast__TOP__clock = vlTOPp->clock;
}

void VSIMDEngine::final() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VSIMDEngine::final\n"); );
    // Variables
    VSIMDEngine__Syms* __restrict vlSymsp = this->__VlSymsp;
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
}

void VSIMDEngine::_eval_settle(VSIMDEngine__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VSIMDEngine::_eval_settle\n"); );
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->_settle__TOP__3(vlSymsp);
    vlTOPp->__Vm_traceActivity[2U] = 1U;
    vlTOPp->__Vm_traceActivity[1U] = 1U;
    vlTOPp->__Vm_traceActivity[0U] = 1U;
}

void VSIMDEngine::_ctor_var_reset() {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VSIMDEngine::_ctor_var_reset\n"); );
    // Body
    clock = VL_RAND_RESET_I(1);
    reset = VL_RAND_RESET_I(1);
    io_cmd_payload_ready = VL_RAND_RESET_I(1);
    io_cmd_payload_valid = VL_RAND_RESET_I(1);
    io_cmd_payload_bits_funct7 = VL_RAND_RESET_I(7);
    io_cmd_payload_bits_funct3 = VL_RAND_RESET_I(3);
    io_cmd_payload_bits_rs1 = VL_RAND_RESET_I(32);
    io_cmd_payload_bits_rs2 = VL_RAND_RESET_I(32);
    io_rsp_payload_ready = VL_RAND_RESET_I(1);
    io_rsp_payload_valid = VL_RAND_RESET_I(1);
    io_rsp_payload_bits_rd = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__controller_io_addSubOpSel = VL_RAND_RESET_I(4);
    SIMDEngine__DOT__controller_io_mulOpSel = VL_RAND_RESET_I(3);
    SIMDEngine__DOT__controller_io_qntOpSel = VL_RAND_RESET_I(3);
    SIMDEngine__DOT__controller_io_wenRs = VL_RAND_RESET_I(1);
    SIMDEngine__DOT__controller_io_outputSel = VL_RAND_RESET_I(2);
    SIMDEngine__DOT__register_io_rsMatch = VL_RAND_RESET_I(1);
    SIMDEngine__DOT__controller__DOT__funct = VL_RAND_RESET_I(10);
    SIMDEngine__DOT__controller__DOT___io_wenRs_T_3 = VL_RAND_RESET_I(1);
    SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_7 = VL_RAND_RESET_I(8);
    SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_14 = VL_RAND_RESET_I(8);
    SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__addSubActivationUnit__DOT__rdByteConcat = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__mulUnit__DOT___T_3 = VL_RAND_RESET_I(3);
    SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_1 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_2 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_3 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__qntUnit__DOT__scaling_factor = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__qntUnit__DOT__zero_point = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_7 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_7 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_7 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_7 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_15 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_15 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_15 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_15 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_23 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_27 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_23 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_27 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_23 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_27 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_23 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_27 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_37 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_37 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_37 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_37 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_45 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_49 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_45 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_49 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_45 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_49 = VL_RAND_RESET_I(31);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_59 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_59 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_59 = VL_RAND_RESET_I(16);
    SIMDEngine__DOT__qntUnit__DOT__rdByteConcat = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__register__DOT__rsReg_0 = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__register__DOT__rsReg_1 = VL_RAND_RESET_I(32);
    SIMDEngine__DOT__register__DOT__rdMsbReg = VL_RAND_RESET_I(32);
    for (int __Vi0=0; __Vi0<3; ++__Vi0) {
        __Vm_traceActivity[__Vi0] = VL_RAND_RESET_I(1);
    }
}

void VSIMDEngine::_configure_coverage(VSIMDEngine__Syms* __restrict vlSymsp, bool first) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VSIMDEngine::_configure_coverage\n"); );
    // Body
    if (false && vlSymsp && first) {}  // Prevent unused
}

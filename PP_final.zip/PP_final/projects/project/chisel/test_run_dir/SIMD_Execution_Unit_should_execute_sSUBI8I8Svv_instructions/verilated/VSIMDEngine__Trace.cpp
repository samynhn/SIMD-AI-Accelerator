// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "VSIMDEngine__Syms.h"


void VSIMDEngine::traceChgTop0(void* userp, VerilatedVcd* tracep) {
    VSIMDEngine__Syms* __restrict vlSymsp = static_cast<VSIMDEngine__Syms*>(userp);
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Variables
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    {
        vlTOPp->traceChgSub0(userp, tracep);
    }
}

void VSIMDEngine::traceChgSub0(void* userp, VerilatedVcd* tracep) {
    VSIMDEngine__Syms* __restrict vlSymsp = static_cast<VSIMDEngine__Syms*>(userp);
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    vluint32_t* const oldp = tracep->oldp(vlSymsp->__Vm_baseCode + 1);
    if (false && oldp) {}  // Prevent unused
    // Body
    {
        if (VL_UNLIKELY(vlTOPp->__Vm_traceActivity[1U])) {
            tracep->chgBit(oldp+0,(vlTOPp->SIMDEngine__DOT__register_io_rsMatch));
            tracep->chgCData(oldp+1,(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel),4);
            tracep->chgCData(oldp+2,(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel),3);
            tracep->chgCData(oldp+3,(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel),3);
            tracep->chgBit(oldp+4,(vlTOPp->SIMDEngine__DOT__controller_io_wenRs));
            tracep->chgCData(oldp+5,(vlTOPp->SIMDEngine__DOT__controller_io_outputSel),2);
            tracep->chgIData(oldp+6,((((IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_3) 
                                       << 0x10U) | (IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_2))),32);
            tracep->chgIData(oldp+7,(((6U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                       ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat
                                       : ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                           ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat
                                           : ((3U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                               ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat
                                               : ((2U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                   ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat
                                                   : 
                                                  ((4U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                    ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat
                                                    : 
                                                   ((1U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                     ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat
                                                     : 0U))))))),32);
            tracep->chgIData(oldp+8,(((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                       ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                       : ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                           ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                           : ((2U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                               ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                               : ((1U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                   ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                                   : 0U))))),32);
            tracep->chgSData(oldp+9,(vlTOPp->SIMDEngine__DOT__controller__DOT__funct),10);
            tracep->chgCData(oldp+10,(((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                        ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_14)
                                        : ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                            ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_7)
                                            : ((3U 
                                                == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_14)
                                                : (
                                                   (1U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_7)
                                                    : 0U))))),8);
            tracep->chgSData(oldp+11,(((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                        ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                        : ((6U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                            ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                            : ((4U 
                                                == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                                : (
                                                   (2U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                                    : 0U))))),16);
            tracep->chgIData(oldp+12,(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT__rdByteConcat),32);
            tracep->chgSData(oldp+13,(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_23),16);
            tracep->chgSData(oldp+14,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_1),16);
            tracep->chgSData(oldp+15,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_2),16);
            tracep->chgSData(oldp+16,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_3),16);
            tracep->chgIData(oldp+17,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat),32);
            tracep->chgIData(oldp+18,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat),32);
            tracep->chgIData(oldp+19,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat),32);
            tracep->chgIData(oldp+20,(vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat),32);
        }
        if (VL_UNLIKELY(vlTOPp->__Vm_traceActivity[2U])) {
            tracep->chgIData(oldp+21,(vlTOPp->SIMDEngine__DOT__register__DOT__rdMsbReg),32);
            tracep->chgIData(oldp+22,(vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor),32);
            tracep->chgIData(oldp+23,(vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point),32);
            tracep->chgIData(oldp+24,(vlTOPp->SIMDEngine__DOT__register__DOT__rsReg_0),32);
            tracep->chgIData(oldp+25,(vlTOPp->SIMDEngine__DOT__register__DOT__rsReg_1),32);
        }
        tracep->chgBit(oldp+26,(vlTOPp->clock));
        tracep->chgBit(oldp+27,(vlTOPp->reset));
        tracep->chgBit(oldp+28,(vlTOPp->io_cmd_payload_ready));
        tracep->chgBit(oldp+29,(vlTOPp->io_cmd_payload_valid));
        tracep->chgCData(oldp+30,(vlTOPp->io_cmd_payload_bits_funct7),7);
        tracep->chgCData(oldp+31,(vlTOPp->io_cmd_payload_bits_funct3),3);
        tracep->chgIData(oldp+32,(vlTOPp->io_cmd_payload_bits_rs1),32);
        tracep->chgIData(oldp+33,(vlTOPp->io_cmd_payload_bits_rs2),32);
        tracep->chgBit(oldp+34,(vlTOPp->io_rsp_payload_ready));
        tracep->chgBit(oldp+35,(vlTOPp->io_rsp_payload_valid));
        tracep->chgIData(oldp+36,(vlTOPp->io_rsp_payload_bits_rd),32);
        tracep->chgBit(oldp+37,(((IData)(vlTOPp->io_cmd_payload_valid) 
                                 & (IData)(vlTOPp->io_rsp_payload_ready))));
        tracep->chgBit(oldp+38,((((IData)(vlTOPp->io_cmd_payload_valid) 
                                  & (IData)(vlTOPp->io_rsp_payload_ready)) 
                                 & (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT___io_wenRs_T_3))));
        tracep->chgIData(oldp+39,((((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)) 
                                    | ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)) 
                                       | ((3U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)) 
                                          | (1U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)))))
                                    ? vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT__rdByteConcat
                                    : ((0xffff0000U 
                                        & (((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                             ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                 >> 0x10U) 
                                                - vlTOPp->io_cmd_payload_bits_rs2)
                                             : ((6U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                 ? 
                                                ((vlTOPp->io_cmd_payload_bits_rs1 
                                                  >> 0x10U) 
                                                 + vlTOPp->io_cmd_payload_bits_rs2)
                                                 : 
                                                ((4U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? 
                                                 ((vlTOPp->io_cmd_payload_bits_rs1 
                                                   >> 0x10U) 
                                                  - 
                                                  (vlTOPp->io_cmd_payload_bits_rs2 
                                                   >> 0x10U))
                                                  : 
                                                 ((2U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? 
                                                  ((vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 0x10U) 
                                                   + 
                                                   (vlTOPp->io_cmd_payload_bits_rs2 
                                                    >> 0x10U))
                                                   : 0U)))) 
                                           << 0x10U)) 
                                       | ((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                           ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                           : ((6U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                               ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                               : ((4U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                                   : 
                                                  ((2U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                                    : 0U))))))),32);
        tracep->chgCData(oldp+40,((0xffU & ((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                             ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                 >> 8U) 
                                                - vlTOPp->io_cmd_payload_bits_rs2)
                                             : ((5U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                 ? 
                                                ((vlTOPp->io_cmd_payload_bits_rs1 
                                                  >> 8U) 
                                                 + vlTOPp->io_cmd_payload_bits_rs2)
                                                 : 
                                                ((3U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? 
                                                 ((vlTOPp->io_cmd_payload_bits_rs1 
                                                   >> 8U) 
                                                  - 
                                                  (vlTOPp->io_cmd_payload_bits_rs2 
                                                   >> 8U))
                                                  : 
                                                 ((1U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? 
                                                  ((vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 8U) 
                                                   + 
                                                   (vlTOPp->io_cmd_payload_bits_rs2 
                                                    >> 8U))
                                                   : 0U)))))),8);
        tracep->chgCData(oldp+41,((0xffU & ((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                             ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                 >> 0x10U) 
                                                - vlTOPp->io_cmd_payload_bits_rs2)
                                             : ((5U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                 ? 
                                                ((vlTOPp->io_cmd_payload_bits_rs1 
                                                  >> 0x10U) 
                                                 + vlTOPp->io_cmd_payload_bits_rs2)
                                                 : 
                                                ((3U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? 
                                                 ((vlTOPp->io_cmd_payload_bits_rs1 
                                                   >> 0x10U) 
                                                  - 
                                                  (vlTOPp->io_cmd_payload_bits_rs2 
                                                   >> 0x10U))
                                                  : 
                                                 ((1U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? 
                                                  ((vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 0x10U) 
                                                   + 
                                                   (vlTOPp->io_cmd_payload_bits_rs2 
                                                    >> 0x10U))
                                                   : 0U)))))),8);
        tracep->chgCData(oldp+42,((0xffU & ((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                             ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                 >> 0x18U) 
                                                - vlTOPp->io_cmd_payload_bits_rs2)
                                             : ((5U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                 ? 
                                                ((vlTOPp->io_cmd_payload_bits_rs1 
                                                  >> 0x18U) 
                                                 + vlTOPp->io_cmd_payload_bits_rs2)
                                                 : 
                                                ((3U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? 
                                                 ((vlTOPp->io_cmd_payload_bits_rs1 
                                                   >> 0x18U) 
                                                  - 
                                                  (vlTOPp->io_cmd_payload_bits_rs2 
                                                   >> 0x18U))
                                                  : 
                                                 ((1U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? 
                                                  ((vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 0x18U) 
                                                   + 
                                                   (vlTOPp->io_cmd_payload_bits_rs2 
                                                    >> 0x18U))
                                                   : 0U)))))),8);
        tracep->chgSData(oldp+43,((0xffffU & ((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                               ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                   >> 0x10U) 
                                                  - vlTOPp->io_cmd_payload_bits_rs2)
                                               : ((6U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? 
                                                  ((vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 0x10U) 
                                                   + vlTOPp->io_cmd_payload_bits_rs2)
                                                   : 
                                                  ((4U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? 
                                                   ((vlTOPp->io_cmd_payload_bits_rs1 
                                                     >> 0x10U) 
                                                    - 
                                                    (vlTOPp->io_cmd_payload_bits_rs2 
                                                     >> 0x10U))
                                                    : 
                                                   ((2U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                     ? 
                                                    ((vlTOPp->io_cmd_payload_bits_rs1 
                                                      >> 0x10U) 
                                                     + 
                                                     (vlTOPp->io_cmd_payload_bits_rs2 
                                                      >> 0x10U))
                                                     : 0U)))))),16);
        tracep->chgIData(oldp+44,(((0xffff0000U & (
                                                   ((8U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                     ? 
                                                    ((vlTOPp->io_cmd_payload_bits_rs1 
                                                      >> 0x10U) 
                                                     - vlTOPp->io_cmd_payload_bits_rs2)
                                                     : 
                                                    ((6U 
                                                      == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                      ? 
                                                     ((vlTOPp->io_cmd_payload_bits_rs1 
                                                       >> 0x10U) 
                                                      + vlTOPp->io_cmd_payload_bits_rs2)
                                                      : 
                                                     ((4U 
                                                       == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                       ? 
                                                      ((vlTOPp->io_cmd_payload_bits_rs1 
                                                        >> 0x10U) 
                                                       - 
                                                       (vlTOPp->io_cmd_payload_bits_rs2 
                                                        >> 0x10U))
                                                       : 
                                                      ((2U 
                                                        == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                        ? 
                                                       ((vlTOPp->io_cmd_payload_bits_rs1 
                                                         >> 0x10U) 
                                                        + 
                                                        (vlTOPp->io_cmd_payload_bits_rs2 
                                                         >> 0x10U))
                                                        : 0U)))) 
                                                   << 0x10U)) 
                                   | ((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                       ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                       : ((6U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                           ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                           : ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                               ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                               : ((2U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                                   : 0U)))))),32);
        tracep->chgCData(oldp+45,((0xffU & ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                             ? ((0xff00U 
                                                 & ((- (IData)(
                                                               (1U 
                                                                & (vlTOPp->io_cmd_payload_bits_rs2 
                                                                   >> 0x1fU)))) 
                                                    << 8U)) 
                                                | (0xffU 
                                                   & (vlTOPp->io_cmd_payload_bits_rs2 
                                                      >> 0x18U)))
                                             : ((5U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                 ? 
                                                (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                  ? 
                                                 (((0x80000000U 
                                                    & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_7 
                                                       << 1U)) 
                                                   | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_7) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                  : 
                                                 (((0xffff0000U 
                                                    & ((- (IData)(
                                                                  (1U 
                                                                   & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_15) 
                                                                      >> 0xfU)))) 
                                                       << 0x10U)) 
                                                   | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_15)) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                 : 
                                                ((1U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                  ? 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_27 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_27) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_37) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_37)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                  : 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_49 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_49) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_59) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_59)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))))),8);
        tracep->chgCData(oldp+46,((0xffU & ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                             ? ((0xff00U 
                                                 & ((- (IData)(
                                                               (1U 
                                                                & (vlTOPp->io_cmd_payload_bits_rs2 
                                                                   >> 0xfU)))) 
                                                    << 8U)) 
                                                | (0xffU 
                                                   & (vlTOPp->io_cmd_payload_bits_rs2 
                                                      >> 8U)))
                                             : ((5U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                 ? 
                                                (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                  ? 
                                                 (((0x80000000U 
                                                    & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_7 
                                                       << 1U)) 
                                                   | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_7) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                  : 
                                                 (((0xffff0000U 
                                                    & ((- (IData)(
                                                                  (1U 
                                                                   & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_15) 
                                                                      >> 0xfU)))) 
                                                       << 0x10U)) 
                                                   | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_15)) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                 : 
                                                ((1U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                  ? 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_27 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_27) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_37) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_37)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                  : 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_49 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_49) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_59) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_59)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))))),8);
        tracep->chgCData(oldp+47,((0xffU & ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                             ? ((0xff00U 
                                                 & ((- (IData)(
                                                               (1U 
                                                                & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                   >> 0x1fU)))) 
                                                    << 8U)) 
                                                | (0xffU 
                                                   & (vlTOPp->io_cmd_payload_bits_rs1 
                                                      >> 0x18U)))
                                             : ((5U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                 ? 
                                                (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                  ? 
                                                 (((0x80000000U 
                                                    & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_7 
                                                       << 1U)) 
                                                   | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_7) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                  : 
                                                 (((0xffff0000U 
                                                    & ((- (IData)(
                                                                  (1U 
                                                                   & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_15) 
                                                                      >> 0xfU)))) 
                                                       << 0x10U)) 
                                                   | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_15)) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                 : 
                                                ((1U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                  ? 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_27 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_27) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_37) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_37)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                  : 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_49 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_49) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_59) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_59)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))))),8);
        tracep->chgCData(oldp+48,((0xffU & ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                             ? ((0xff00U 
                                                 & ((- (IData)(
                                                               (1U 
                                                                & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                   >> 0xfU)))) 
                                                    << 8U)) 
                                                | (0xffU 
                                                   & (vlTOPp->io_cmd_payload_bits_rs1 
                                                      >> 8U)))
                                             : ((5U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                 ? 
                                                (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                  ? 
                                                 (((0x80000000U 
                                                    & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_7 
                                                       << 1U)) 
                                                   | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_7) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                  : 
                                                 (((0xffff0000U 
                                                    & ((- (IData)(
                                                                  (1U 
                                                                   & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_15) 
                                                                      >> 0xfU)))) 
                                                       << 0x10U)) 
                                                   | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_15)) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                 : 
                                                (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                  ? 
                                                 (((0x80000000U 
                                                    & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_27 
                                                       << 1U)) 
                                                   | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_27) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                  : 
                                                 (((0xffff0000U 
                                                    & ((- (IData)(
                                                                  (1U 
                                                                   & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_37) 
                                                                      >> 0xfU)))) 
                                                       << 0x10U)) 
                                                   | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_37)) 
                                                  + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)))))),8);
    }
}

void VSIMDEngine::traceCleanup(void* userp, VerilatedVcd* /*unused*/) {
    VSIMDEngine__Syms* __restrict vlSymsp = static_cast<VSIMDEngine__Syms*>(userp);
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    {
        vlSymsp->__Vm_activity = false;
        vlTOPp->__Vm_traceActivity[0U] = 0U;
        vlTOPp->__Vm_traceActivity[1U] = 0U;
        vlTOPp->__Vm_traceActivity[2U] = 0U;
    }
}

// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_c.h"
#include "VSIMDEngine__Syms.h"


//======================

void VSIMDEngine::trace(VerilatedVcdC* tfp, int, int) {
    tfp->spTrace()->addInitCb(&traceInit, __VlSymsp);
    traceRegister(tfp->spTrace());
}

void VSIMDEngine::traceInit(void* userp, VerilatedVcd* tracep, uint32_t code) {
    // Callback from tracep->open()
    VSIMDEngine__Syms* __restrict vlSymsp = static_cast<VSIMDEngine__Syms*>(userp);
    if (!vlSymsp->_vm_contextp__->calcUnusedSigs()) {
        VL_FATAL_MT(__FILE__, __LINE__, __FILE__,
                        "Turning on wave traces requires Verilated::traceEverOn(true) call before time 0.");
    }
    vlSymsp->__Vm_baseCode = code;
    tracep->module(vlSymsp->name());
    tracep->scopeEscape(' ');
    VSIMDEngine::traceInitTop(vlSymsp, tracep);
    tracep->scopeEscape('.');
}

//======================


void VSIMDEngine::traceInitTop(void* userp, VerilatedVcd* tracep) {
    VSIMDEngine__Syms* __restrict vlSymsp = static_cast<VSIMDEngine__Syms*>(userp);
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    {
        vlTOPp->traceInitSub0(userp, tracep);
    }
}

void VSIMDEngine::traceInitSub0(void* userp, VerilatedVcd* tracep) {
    VSIMDEngine__Syms* __restrict vlSymsp = static_cast<VSIMDEngine__Syms*>(userp);
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    const int c = vlSymsp->__Vm_baseCode;
    if (false && tracep && c) {}  // Prevent unused
    // Body
    {
        tracep->declBit(c+27,"clock", false,-1);
        tracep->declBit(c+28,"reset", false,-1);
        tracep->declBit(c+29,"io_cmd_payload_ready", false,-1);
        tracep->declBit(c+30,"io_cmd_payload_valid", false,-1);
        tracep->declBus(c+31,"io_cmd_payload_bits_funct7", false,-1, 6,0);
        tracep->declBus(c+32,"io_cmd_payload_bits_funct3", false,-1, 2,0);
        tracep->declBus(c+33,"io_cmd_payload_bits_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"io_cmd_payload_bits_rs2", false,-1, 31,0);
        tracep->declBit(c+35,"io_rsp_payload_ready", false,-1);
        tracep->declBit(c+36,"io_rsp_payload_valid", false,-1);
        tracep->declBus(c+37,"io_rsp_payload_bits_rd", false,-1, 31,0);
        tracep->declBit(c+27,"SIMDEngine clock", false,-1);
        tracep->declBit(c+28,"SIMDEngine reset", false,-1);
        tracep->declBit(c+29,"SIMDEngine io_cmd_payload_ready", false,-1);
        tracep->declBit(c+30,"SIMDEngine io_cmd_payload_valid", false,-1);
        tracep->declBus(c+31,"SIMDEngine io_cmd_payload_bits_funct7", false,-1, 6,0);
        tracep->declBus(c+32,"SIMDEngine io_cmd_payload_bits_funct3", false,-1, 2,0);
        tracep->declBus(c+33,"SIMDEngine io_cmd_payload_bits_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"SIMDEngine io_cmd_payload_bits_rs2", false,-1, 31,0);
        tracep->declBit(c+35,"SIMDEngine io_rsp_payload_ready", false,-1);
        tracep->declBit(c+36,"SIMDEngine io_rsp_payload_valid", false,-1);
        tracep->declBus(c+37,"SIMDEngine io_rsp_payload_bits_rd", false,-1, 31,0);
        tracep->declBit(c+30,"SIMDEngine controller_io_cmd_payload_valid", false,-1);
        tracep->declBus(c+31,"SIMDEngine controller_io_cmd_payload_bits_funct7", false,-1, 6,0);
        tracep->declBus(c+32,"SIMDEngine controller_io_cmd_payload_bits_funct3", false,-1, 2,0);
        tracep->declBit(c+35,"SIMDEngine controller_io_rsp_payload_ready", false,-1);
        tracep->declBit(c+38,"SIMDEngine controller_io_rsp_payload_valid", false,-1);
        tracep->declBit(c+1,"SIMDEngine controller_io_rsMatch", false,-1);
        tracep->declBus(c+2,"SIMDEngine controller_io_addSubOpSel", false,-1, 3,0);
        tracep->declBus(c+3,"SIMDEngine controller_io_mulOpSel", false,-1, 2,0);
        tracep->declBus(c+4,"SIMDEngine controller_io_qntOpSel", false,-1, 2,0);
        tracep->declBit(c+5,"SIMDEngine controller_io_wenRs", false,-1);
        tracep->declBit(c+39,"SIMDEngine controller_io_wenRd", false,-1);
        tracep->declBus(c+6,"SIMDEngine controller_io_outputSel", false,-1, 1,0);
        tracep->declBus(c+2,"SIMDEngine addSubActivationUnit_io_opSel", false,-1, 3,0);
        tracep->declBus(c+33,"SIMDEngine addSubActivationUnit_io_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"SIMDEngine addSubActivationUnit_io_rs2", false,-1, 31,0);
        tracep->declBus(c+40,"SIMDEngine addSubActivationUnit_io_rd", false,-1, 31,0);
        tracep->declBus(c+3,"SIMDEngine mulUnit_io_opSel", false,-1, 2,0);
        tracep->declBus(c+33,"SIMDEngine mulUnit_io_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"SIMDEngine mulUnit_io_rs2", false,-1, 31,0);
        tracep->declBus(c+7,"SIMDEngine mulUnit_io_rdMsb", false,-1, 31,0);
        tracep->declBus(c+8,"SIMDEngine mulUnit_io_rd", false,-1, 31,0);
        tracep->declBit(c+27,"SIMDEngine qntUnit_clock", false,-1);
        tracep->declBit(c+28,"SIMDEngine qntUnit_reset", false,-1);
        tracep->declBus(c+4,"SIMDEngine qntUnit_io_opSel", false,-1, 2,0);
        tracep->declBus(c+33,"SIMDEngine qntUnit_io_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"SIMDEngine qntUnit_io_rs2", false,-1, 31,0);
        tracep->declBus(c+9,"SIMDEngine qntUnit_io_rd", false,-1, 31,0);
        tracep->declBit(c+27,"SIMDEngine register_clock", false,-1);
        tracep->declBit(c+28,"SIMDEngine register_reset", false,-1);
        tracep->declBus(c+33,"SIMDEngine register_io_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"SIMDEngine register_io_rs2", false,-1, 31,0);
        tracep->declBus(c+7,"SIMDEngine register_io_rdMsbIn", false,-1, 31,0);
        tracep->declBit(c+5,"SIMDEngine register_io_wenRs", false,-1);
        tracep->declBit(c+39,"SIMDEngine register_io_wenRd", false,-1);
        tracep->declBit(c+1,"SIMDEngine register_io_rsMatch", false,-1);
        tracep->declBus(c+22,"SIMDEngine register_io_rdMsbOut", false,-1, 31,0);
        tracep->declBit(c+30,"SIMDEngine controller io_cmd_payload_valid", false,-1);
        tracep->declBus(c+31,"SIMDEngine controller io_cmd_payload_bits_funct7", false,-1, 6,0);
        tracep->declBus(c+32,"SIMDEngine controller io_cmd_payload_bits_funct3", false,-1, 2,0);
        tracep->declBit(c+35,"SIMDEngine controller io_rsp_payload_ready", false,-1);
        tracep->declBit(c+38,"SIMDEngine controller io_rsp_payload_valid", false,-1);
        tracep->declBit(c+1,"SIMDEngine controller io_rsMatch", false,-1);
        tracep->declBus(c+2,"SIMDEngine controller io_addSubOpSel", false,-1, 3,0);
        tracep->declBus(c+3,"SIMDEngine controller io_mulOpSel", false,-1, 2,0);
        tracep->declBus(c+4,"SIMDEngine controller io_qntOpSel", false,-1, 2,0);
        tracep->declBit(c+5,"SIMDEngine controller io_wenRs", false,-1);
        tracep->declBit(c+39,"SIMDEngine controller io_wenRd", false,-1);
        tracep->declBus(c+6,"SIMDEngine controller io_outputSel", false,-1, 1,0);
        tracep->declBus(c+10,"SIMDEngine controller funct", false,-1, 9,0);
        tracep->declBus(c+2,"SIMDEngine addSubActivationUnit io_opSel", false,-1, 3,0);
        tracep->declBus(c+33,"SIMDEngine addSubActivationUnit io_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"SIMDEngine addSubActivationUnit io_rs2", false,-1, 31,0);
        tracep->declBus(c+40,"SIMDEngine addSubActivationUnit io_rd", false,-1, 31,0);
        tracep->declBus(c+11,"SIMDEngine addSubActivationUnit rdByteArray_0", false,-1, 7,0);
        tracep->declBus(c+41,"SIMDEngine addSubActivationUnit rdByteArray_1", false,-1, 7,0);
        tracep->declBus(c+42,"SIMDEngine addSubActivationUnit rdByteArray_2", false,-1, 7,0);
        tracep->declBus(c+43,"SIMDEngine addSubActivationUnit rdByteArray_3", false,-1, 7,0);
        tracep->declBus(c+12,"SIMDEngine addSubActivationUnit rdHalfArray_0", false,-1, 15,0);
        tracep->declBus(c+44,"SIMDEngine addSubActivationUnit rdHalfArray_1", false,-1, 15,0);
        tracep->declBus(c+13,"SIMDEngine addSubActivationUnit rdByteConcat", false,-1, 31,0);
        tracep->declBus(c+45,"SIMDEngine addSubActivationUnit rdHalfConcat", false,-1, 31,0);
        tracep->declBus(c+3,"SIMDEngine mulUnit io_opSel", false,-1, 2,0);
        tracep->declBus(c+33,"SIMDEngine mulUnit io_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"SIMDEngine mulUnit io_rs2", false,-1, 31,0);
        tracep->declBus(c+7,"SIMDEngine mulUnit io_rdMsb", false,-1, 31,0);
        tracep->declBus(c+8,"SIMDEngine mulUnit io_rd", false,-1, 31,0);
        tracep->declBus(c+14,"SIMDEngine mulUnit rdHalfArray_0", false,-1, 15,0);
        tracep->declBus(c+15,"SIMDEngine mulUnit rdHalfArray_1", false,-1, 15,0);
        tracep->declBus(c+16,"SIMDEngine mulUnit rdHalfArray_2", false,-1, 15,0);
        tracep->declBus(c+17,"SIMDEngine mulUnit rdHalfArray_3", false,-1, 15,0);
        tracep->declBus(c+18,"SIMDEngine mulUnit rdMsbByteConcat", false,-1, 31,0);
        tracep->declBus(c+19,"SIMDEngine mulUnit rdLsbHalfConcat", false,-1, 31,0);
        tracep->declBus(c+20,"SIMDEngine mulUnit rdMsbHalfConcat", false,-1, 31,0);
        tracep->declBit(c+27,"SIMDEngine qntUnit clock", false,-1);
        tracep->declBit(c+28,"SIMDEngine qntUnit reset", false,-1);
        tracep->declBus(c+4,"SIMDEngine qntUnit io_opSel", false,-1, 2,0);
        tracep->declBus(c+33,"SIMDEngine qntUnit io_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"SIMDEngine qntUnit io_rs2", false,-1, 31,0);
        tracep->declBus(c+9,"SIMDEngine qntUnit io_rd", false,-1, 31,0);
        tracep->declBus(c+23,"SIMDEngine qntUnit scaling_factor", false,-1, 31,0);
        tracep->declBus(c+24,"SIMDEngine qntUnit zero_point", false,-1, 31,0);
        tracep->declBus(c+46,"SIMDEngine qntUnit rdByteArray_3", false,-1, 7,0);
        tracep->declBus(c+47,"SIMDEngine qntUnit rdByteArray_2", false,-1, 7,0);
        tracep->declBus(c+48,"SIMDEngine qntUnit rdByteArray_1", false,-1, 7,0);
        tracep->declBus(c+49,"SIMDEngine qntUnit rdByteArray_0", false,-1, 7,0);
        tracep->declBus(c+21,"SIMDEngine qntUnit rdByteConcat", false,-1, 31,0);
        tracep->declBit(c+27,"SIMDEngine register clock", false,-1);
        tracep->declBit(c+28,"SIMDEngine register reset", false,-1);
        tracep->declBus(c+33,"SIMDEngine register io_rs1", false,-1, 31,0);
        tracep->declBus(c+34,"SIMDEngine register io_rs2", false,-1, 31,0);
        tracep->declBus(c+7,"SIMDEngine register io_rdMsbIn", false,-1, 31,0);
        tracep->declBit(c+5,"SIMDEngine register io_wenRs", false,-1);
        tracep->declBit(c+39,"SIMDEngine register io_wenRd", false,-1);
        tracep->declBit(c+1,"SIMDEngine register io_rsMatch", false,-1);
        tracep->declBus(c+22,"SIMDEngine register io_rdMsbOut", false,-1, 31,0);
        tracep->declBus(c+25,"SIMDEngine register rsReg_0", false,-1, 31,0);
        tracep->declBus(c+26,"SIMDEngine register rsReg_1", false,-1, 31,0);
        tracep->declBus(c+22,"SIMDEngine register rdMsbReg", false,-1, 31,0);
    }
}

void VSIMDEngine::traceRegister(VerilatedVcd* tracep) {
    // Body
    {
        tracep->addFullCb(&traceFullTop0, __VlSymsp);
        tracep->addChgCb(&traceChgTop0, __VlSymsp);
        tracep->addCleanupCb(&traceCleanup, __VlSymsp);
    }
}

void VSIMDEngine::traceFullTop0(void* userp, VerilatedVcd* tracep) {
    VSIMDEngine__Syms* __restrict vlSymsp = static_cast<VSIMDEngine__Syms*>(userp);
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    {
        vlTOPp->traceFullSub0(userp, tracep);
    }
}

void VSIMDEngine::traceFullSub0(void* userp, VerilatedVcd* tracep) {
    VSIMDEngine__Syms* __restrict vlSymsp = static_cast<VSIMDEngine__Syms*>(userp);
    VSIMDEngine* const __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    vluint32_t* const oldp = tracep->oldp(vlSymsp->__Vm_baseCode);
    if (false && oldp) {}  // Prevent unused
    // Body
    {
        tracep->fullBit(oldp+1,(vlTOPp->SIMDEngine__DOT__register_io_rsMatch));
        tracep->fullCData(oldp+2,(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel),4);
        tracep->fullCData(oldp+3,(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel),3);
        tracep->fullCData(oldp+4,(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel),3);
        tracep->fullBit(oldp+5,(vlTOPp->SIMDEngine__DOT__controller_io_wenRs));
        tracep->fullCData(oldp+6,(vlTOPp->SIMDEngine__DOT__controller_io_outputSel),2);
        tracep->fullIData(oldp+7,((((IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_3) 
                                    << 0x10U) | (IData)(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_2))),32);
        tracep->fullIData(oldp+8,(((6U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                    ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat
                                    : ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                        ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat
                                        : ((3U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                            ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat
                                            : ((2U 
                                                == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat
                                                : (
                                                   (4U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                    ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat
                                                    : 
                                                   ((1U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_mulOpSel))
                                                     ? vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat
                                                     : 0U))))))),32);
        tracep->fullIData(oldp+9,(((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                    ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                    : ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                        ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                        : ((2U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                            ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                            : ((1U 
                                                == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                ? vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat
                                                : 0U))))),32);
        tracep->fullSData(oldp+10,(vlTOPp->SIMDEngine__DOT__controller__DOT__funct),10);
        tracep->fullCData(oldp+11,(((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                     ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_14)
                                     : ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                         ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_7)
                                         : ((3U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                             ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_14)
                                             : ((1U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                 ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdByteArray_0_T_7)
                                                 : 0U))))),8);
        tracep->fullSData(oldp+12,(((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                     ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                     : ((6U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                         ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                         : ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                             ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                             : ((2U 
                                                 == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                 ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                                 : 0U))))),16);
        tracep->fullIData(oldp+13,(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT__rdByteConcat),32);
        tracep->fullSData(oldp+14,(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_23),16);
        tracep->fullSData(oldp+15,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_1),16);
        tracep->fullSData(oldp+16,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_2),16);
        tracep->fullSData(oldp+17,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdHalfArray_3),16);
        tracep->fullIData(oldp+18,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbByteConcat),32);
        tracep->fullIData(oldp+19,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdLsbHalfConcat),32);
        tracep->fullIData(oldp+20,(vlTOPp->SIMDEngine__DOT__mulUnit__DOT__rdMsbHalfConcat),32);
        tracep->fullIData(oldp+21,(vlTOPp->SIMDEngine__DOT__qntUnit__DOT__rdByteConcat),32);
        tracep->fullIData(oldp+22,(vlTOPp->SIMDEngine__DOT__register__DOT__rdMsbReg),32);
        tracep->fullIData(oldp+23,(vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor),32);
        tracep->fullIData(oldp+24,(vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point),32);
        tracep->fullIData(oldp+25,(vlTOPp->SIMDEngine__DOT__register__DOT__rsReg_0),32);
        tracep->fullIData(oldp+26,(vlTOPp->SIMDEngine__DOT__register__DOT__rsReg_1),32);
        tracep->fullBit(oldp+27,(vlTOPp->clock));
        tracep->fullBit(oldp+28,(vlTOPp->reset));
        tracep->fullBit(oldp+29,(vlTOPp->io_cmd_payload_ready));
        tracep->fullBit(oldp+30,(vlTOPp->io_cmd_payload_valid));
        tracep->fullCData(oldp+31,(vlTOPp->io_cmd_payload_bits_funct7),7);
        tracep->fullCData(oldp+32,(vlTOPp->io_cmd_payload_bits_funct3),3);
        tracep->fullIData(oldp+33,(vlTOPp->io_cmd_payload_bits_rs1),32);
        tracep->fullIData(oldp+34,(vlTOPp->io_cmd_payload_bits_rs2),32);
        tracep->fullBit(oldp+35,(vlTOPp->io_rsp_payload_ready));
        tracep->fullBit(oldp+36,(vlTOPp->io_rsp_payload_valid));
        tracep->fullIData(oldp+37,(vlTOPp->io_rsp_payload_bits_rd),32);
        tracep->fullBit(oldp+38,(((IData)(vlTOPp->io_cmd_payload_valid) 
                                  & (IData)(vlTOPp->io_rsp_payload_ready))));
        tracep->fullBit(oldp+39,((((IData)(vlTOPp->io_cmd_payload_valid) 
                                   & (IData)(vlTOPp->io_rsp_payload_ready)) 
                                  & (IData)(vlTOPp->SIMDEngine__DOT__controller__DOT___io_wenRs_T_3))));
        tracep->fullIData(oldp+40,((((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)) 
                                     | ((5U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)) 
                                        | ((3U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)) 
                                           | (1U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel)))))
                                     ? vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT__rdByteConcat
                                     : ((0xffff0000U 
                                         & (((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                              ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                  >> 0x10U) 
                                                 - vlTOPp->io_cmd_payload_bits_rs2)
                                              : ((6U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? 
                                                 ((vlTOPp->io_cmd_payload_bits_rs1 
                                                   >> 0x10U) 
                                                  + vlTOPp->io_cmd_payload_bits_rs2)
                                                  : 
                                                 ((4U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? 
                                                  ((vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 0x10U) 
                                                   - 
                                                   (vlTOPp->io_cmd_payload_bits_rs2 
                                                    >> 0x10U))
                                                   : 
                                                  ((2U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? 
                                                   ((vlTOPp->io_cmd_payload_bits_rs1 
                                                     >> 0x10U) 
                                                    + 
                                                    (vlTOPp->io_cmd_payload_bits_rs2 
                                                     >> 0x10U))
                                                    : 0U)))) 
                                            << 0x10U)) 
                                        | ((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                            ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                            : ((6U 
                                                == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                                : (
                                                   (4U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                                    : 
                                                   ((2U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                     ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                                     : 0U))))))),32);
        tracep->fullCData(oldp+41,((0xffU & ((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                              ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                  >> 8U) 
                                                 - vlTOPp->io_cmd_payload_bits_rs2)
                                              : ((5U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? 
                                                 ((vlTOPp->io_cmd_payload_bits_rs1 
                                                   >> 8U) 
                                                  + vlTOPp->io_cmd_payload_bits_rs2)
                                                  : 
                                                 ((3U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? 
                                                  ((vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 8U) 
                                                   - 
                                                   (vlTOPp->io_cmd_payload_bits_rs2 
                                                    >> 8U))
                                                   : 
                                                  ((1U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? 
                                                   ((vlTOPp->io_cmd_payload_bits_rs1 
                                                     >> 8U) 
                                                    + 
                                                    (vlTOPp->io_cmd_payload_bits_rs2 
                                                     >> 8U))
                                                    : 0U)))))),8);
        tracep->fullCData(oldp+42,((0xffU & ((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                              ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                  >> 0x10U) 
                                                 - vlTOPp->io_cmd_payload_bits_rs2)
                                              : ((5U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? 
                                                 ((vlTOPp->io_cmd_payload_bits_rs1 
                                                   >> 0x10U) 
                                                  + vlTOPp->io_cmd_payload_bits_rs2)
                                                  : 
                                                 ((3U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? 
                                                  ((vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 0x10U) 
                                                   - 
                                                   (vlTOPp->io_cmd_payload_bits_rs2 
                                                    >> 0x10U))
                                                   : 
                                                  ((1U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? 
                                                   ((vlTOPp->io_cmd_payload_bits_rs1 
                                                     >> 0x10U) 
                                                    + 
                                                    (vlTOPp->io_cmd_payload_bits_rs2 
                                                     >> 0x10U))
                                                    : 0U)))))),8);
        tracep->fullCData(oldp+43,((0xffU & ((7U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                              ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                  >> 0x18U) 
                                                 - vlTOPp->io_cmd_payload_bits_rs2)
                                              : ((5U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? 
                                                 ((vlTOPp->io_cmd_payload_bits_rs1 
                                                   >> 0x18U) 
                                                  + vlTOPp->io_cmd_payload_bits_rs2)
                                                  : 
                                                 ((3U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                   ? 
                                                  ((vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 0x18U) 
                                                   - 
                                                   (vlTOPp->io_cmd_payload_bits_rs2 
                                                    >> 0x18U))
                                                   : 
                                                  ((1U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? 
                                                   ((vlTOPp->io_cmd_payload_bits_rs1 
                                                     >> 0x18U) 
                                                    + 
                                                    (vlTOPp->io_cmd_payload_bits_rs2 
                                                     >> 0x18U))
                                                    : 0U)))))),8);
        tracep->fullSData(oldp+44,((0xffffU & ((8U 
                                                == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                ? (
                                                   (vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 0x10U) 
                                                   - vlTOPp->io_cmd_payload_bits_rs2)
                                                : (
                                                   (6U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? 
                                                   ((vlTOPp->io_cmd_payload_bits_rs1 
                                                     >> 0x10U) 
                                                    + vlTOPp->io_cmd_payload_bits_rs2)
                                                    : 
                                                   ((4U 
                                                     == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                     ? 
                                                    ((vlTOPp->io_cmd_payload_bits_rs1 
                                                      >> 0x10U) 
                                                     - 
                                                     (vlTOPp->io_cmd_payload_bits_rs2 
                                                      >> 0x10U))
                                                     : 
                                                    ((2U 
                                                      == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                      ? 
                                                     ((vlTOPp->io_cmd_payload_bits_rs1 
                                                       >> 0x10U) 
                                                      + 
                                                      (vlTOPp->io_cmd_payload_bits_rs2 
                                                       >> 0x10U))
                                                      : 0U)))))),16);
        tracep->fullIData(oldp+45,(((0xffff0000U & 
                                     (((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                        ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                            >> 0x10U) 
                                           - vlTOPp->io_cmd_payload_bits_rs2)
                                        : ((6U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                            ? ((vlTOPp->io_cmd_payload_bits_rs1 
                                                >> 0x10U) 
                                               + vlTOPp->io_cmd_payload_bits_rs2)
                                            : ((4U 
                                                == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                ? (
                                                   (vlTOPp->io_cmd_payload_bits_rs1 
                                                    >> 0x10U) 
                                                   - 
                                                   (vlTOPp->io_cmd_payload_bits_rs2 
                                                    >> 0x10U))
                                                : (
                                                   (2U 
                                                    == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                    ? 
                                                   ((vlTOPp->io_cmd_payload_bits_rs1 
                                                     >> 0x10U) 
                                                    + 
                                                    (vlTOPp->io_cmd_payload_bits_rs2 
                                                     >> 0x10U))
                                                    : 0U)))) 
                                      << 0x10U)) | 
                                    ((8U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                      ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                      : ((6U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                          ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                          : ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                              ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_14)
                                              : ((2U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_addSubOpSel))
                                                  ? (IData)(vlTOPp->SIMDEngine__DOT__addSubActivationUnit__DOT___rdHalfArray_0_T_7)
                                                  : 0U)))))),32);
        tracep->fullCData(oldp+46,((0xffU & ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                              ? ((0xff00U 
                                                  & ((- (IData)(
                                                                (1U 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs2 
                                                                    >> 0x1fU)))) 
                                                     << 8U)) 
                                                 | (0xffU 
                                                    & (vlTOPp->io_cmd_payload_bits_rs2 
                                                       >> 0x18U)))
                                              : ((5U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                  ? 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_7 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_7) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_15) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_15)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                  : 
                                                 ((1U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                   ? 
                                                  (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                    ? 
                                                   (((0x80000000U 
                                                      & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_27 
                                                         << 1U)) 
                                                     | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_27) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                    : 
                                                   (((0xffff0000U 
                                                      & ((- (IData)(
                                                                    (1U 
                                                                     & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_37) 
                                                                        >> 0xfU)))) 
                                                         << 0x10U)) 
                                                     | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_37)) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                   : 
                                                  (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                    ? 
                                                   (((0x80000000U 
                                                      & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_49 
                                                         << 1U)) 
                                                     | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_49) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                    : 
                                                   (((0xffff0000U 
                                                      & ((- (IData)(
                                                                    (1U 
                                                                     & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_59) 
                                                                        >> 0xfU)))) 
                                                         << 0x10U)) 
                                                     | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_3_T_59)) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))))),8);
        tracep->fullCData(oldp+47,((0xffU & ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                              ? ((0xff00U 
                                                  & ((- (IData)(
                                                                (1U 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs2 
                                                                    >> 0xfU)))) 
                                                     << 8U)) 
                                                 | (0xffU 
                                                    & (vlTOPp->io_cmd_payload_bits_rs2 
                                                       >> 8U)))
                                              : ((5U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                  ? 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_7 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_7) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_15) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_15)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                  : 
                                                 ((1U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                   ? 
                                                  (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                    ? 
                                                   (((0x80000000U 
                                                      & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_27 
                                                         << 1U)) 
                                                     | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_27) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                    : 
                                                   (((0xffff0000U 
                                                      & ((- (IData)(
                                                                    (1U 
                                                                     & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_37) 
                                                                        >> 0xfU)))) 
                                                         << 0x10U)) 
                                                     | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_37)) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                   : 
                                                  (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                    ? 
                                                   (((0x80000000U 
                                                      & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_49 
                                                         << 1U)) 
                                                     | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_49) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                    : 
                                                   (((0xffff0000U 
                                                      & ((- (IData)(
                                                                    (1U 
                                                                     & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_59) 
                                                                        >> 0xfU)))) 
                                                         << 0x10U)) 
                                                     | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_2_T_59)) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))))),8);
        tracep->fullCData(oldp+48,((0xffU & ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                              ? ((0xff00U 
                                                  & ((- (IData)(
                                                                (1U 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                    >> 0x1fU)))) 
                                                     << 8U)) 
                                                 | (0xffU 
                                                    & (vlTOPp->io_cmd_payload_bits_rs1 
                                                       >> 0x18U)))
                                              : ((5U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                  ? 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_7 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_7) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_15) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_15)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                  : 
                                                 ((1U 
                                                   == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                   ? 
                                                  (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                    ? 
                                                   (((0x80000000U 
                                                      & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_27 
                                                         << 1U)) 
                                                     | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_27) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                    : 
                                                   (((0xffff0000U 
                                                      & ((- (IData)(
                                                                    (1U 
                                                                     & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_37) 
                                                                        >> 0xfU)))) 
                                                         << 0x10U)) 
                                                     | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_37)) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                   : 
                                                  (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                    ? 
                                                   (((0x80000000U 
                                                      & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_49 
                                                         << 1U)) 
                                                     | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_49) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                    : 
                                                   (((0xffff0000U 
                                                      & ((- (IData)(
                                                                    (1U 
                                                                     & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_59) 
                                                                        >> 0xfU)))) 
                                                         << 0x10U)) 
                                                     | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_1_T_59)) 
                                                    + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))))))),8);
        tracep->fullCData(oldp+49,((0xffU & ((4U == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                              ? ((0xff00U 
                                                  & ((- (IData)(
                                                                (1U 
                                                                 & (vlTOPp->io_cmd_payload_bits_rs1 
                                                                    >> 0xfU)))) 
                                                     << 8U)) 
                                                 | (0xffU 
                                                    & (vlTOPp->io_cmd_payload_bits_rs1 
                                                       >> 8U)))
                                              : ((5U 
                                                  == (IData)(vlTOPp->SIMDEngine__DOT__controller_io_qntOpSel))
                                                  ? 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_7 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_7) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_15) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_15)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point))
                                                  : 
                                                 (VL_GTS_III(1,32,32, 0U, vlTOPp->SIMDEngine__DOT__qntUnit__DOT__scaling_factor)
                                                   ? 
                                                  (((0x80000000U 
                                                     & (vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_27 
                                                        << 1U)) 
                                                    | vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_27) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)
                                                   : 
                                                  (((0xffff0000U 
                                                     & ((- (IData)(
                                                                   (1U 
                                                                    & ((IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_37) 
                                                                       >> 0xfU)))) 
                                                        << 0x10U)) 
                                                    | (IData)(vlTOPp->SIMDEngine__DOT__qntUnit__DOT___rdByteArray_0_T_37)) 
                                                   + vlTOPp->SIMDEngine__DOT__qntUnit__DOT__zero_point)))))),8);
    }
}

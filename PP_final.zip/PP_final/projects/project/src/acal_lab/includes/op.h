#ifndef SRC_ACAL_LAB_INCLUDES_OP_H_
#define SRC_ACAL_LAB_INCLUDES_OP_H_

#include "op/scalar.h"
#include "op/simd.h"

#endif  // SRC_ACAL_LAB_INCLUDES_OP_H_
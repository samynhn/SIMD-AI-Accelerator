#ifndef SRC_ACAL_LAB_INCLUDES_INSTRUCTION_H_
#define SRC_ACAL_LAB_INCLUDES_INSTRUCTION_H_

#include "instruction/SimdFuse.h"
#include "instruction/SimdInst.h"

#endif  // SRC_ACAL_LAB_INCLUDES_INSTRUCTION_H_
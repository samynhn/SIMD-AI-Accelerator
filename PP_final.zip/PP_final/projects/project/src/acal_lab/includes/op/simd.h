#ifndef SRC_ACAL_LAB_INCLUDES_OP_SIMD_H_
#define SRC_ACAL_LAB_INCLUDES_OP_SIMD_H_

#include "simd/Conv.h"
#include "simd/Gemm.h"
#include "simd/MxPl.h"
#include "simd/ReLU.h"

#endif  // SRC_ACAL_LAB_INCLUDES_OP_SIMD_H_
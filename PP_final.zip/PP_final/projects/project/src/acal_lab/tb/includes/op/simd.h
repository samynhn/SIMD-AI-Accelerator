#ifndef SRC_ACAL_LAB_TB_INCLUDES_OP_SIMD_H_
#define SRC_ACAL_LAB_TB_INCLUDES_OP_SIMD_H_

#include "simd/tb_Conv.h"
#include "simd/tb_Gemm.h"
#include "simd/tb_MxPl.h"
#include "simd/tb_ReLU.h"

#endif  // SRC_ACAL_LAB_TB_INCLUDES_OP_SIMD_H_

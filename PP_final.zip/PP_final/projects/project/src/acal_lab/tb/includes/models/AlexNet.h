#ifndef SRC_ACAL_LAB_TB_INCLUDES_MODELS_ALEXNET_H_
#define SRC_ACAL_LAB_TB_INCLUDES_MODELS_ALEXNET_H_

#include "AlexNet/tb_AlexNet.h"
#include "AlexNet/tb_AlexNetConfig.h"

#endif  // SRC_ACAL_LAB_TB_INCLUDES_MODELS_ALEXNET_H_
#!/bin/bash

bash "/usr/local/bin/startup"
